package com.example.myimageapp

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

public class MainActivity extends AppCompatActivity {
    int 1;
    override fun onClick(View view) {
        ImageView img =(ImageView) findViewById (R.id.img);
        if (i == 1) {
            i = 2;
            img.setImageResource(R.drawable.car1);
        } else {
            i = 1;
            img.setImageResource(R.drawable.car2)
        }
    }
}

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
